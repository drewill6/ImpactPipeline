﻿document.addEventListener('DOMContentLoaded', function () {
    window.initializeParallax = function () {
        var background1 = document.querySelector('.background1');
        var background2 = document.querySelector('.background2');
        var background3 = document.querySelector('.background3');

        window.addEventListener('scroll', function () {
            var scrolled = window.scrollY;
            var windowHeight = window.innerHeight;

            // Calculate the scroll position relative to each image
            var scrollPosition1 = scrolled - windowHeight; // Image 1 starts at the page
            var scrollPosition2 = scrolled - 2 * windowHeight; // Image 2 starts after the first image
            var scrollPosition3 = scrolled - 3 * windowHeight; // Image 3 starts after the second image


            // Adjust the speed of parallax scrolling by changing the multiplier (e.g., 0.2)
            background1.style.opacity = calculateOpacity(scrollPosition1);
            background2.style.opacity = calculateOpacity(scrollPosition2);
            background3.style.opacity = calculateOpacity(scrollPosition3);
        });

        // Helper function to calculate the opacity based on scroll position
        function calculateOpacity(scrollPosition) {
            // Set a threshold for visibility (adjust as needed)
            var visibilityThreshold = 400;

            //Ensure scrollPosition is always positive
            //var positiveScrollPosition = Math.abs(scrollPosition);

            // Calculate opacity based on the scroll position and visibility threshold
            var opacity = 1 - Math.max(0, Math.abs(scrollPosition) - visibilityThreshold) / visibilityThreshold;

            // Ensure opacity is between 0 and 1 
            return Math.min(1, Math.max(0, opacity));
        }

    };

    window.initializeParallax(); // Call the function to initialize parallax effect

});