﻿namespace DataImpact.Models
{
    public class IndustryModels
    {
        public int Id { get; set; }
        public string? IndustryName { get; set; }
        public string? IndustryDescription { get; set; }

    }
}
